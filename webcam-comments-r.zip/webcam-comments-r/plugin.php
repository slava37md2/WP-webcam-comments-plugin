<?php
/*
Plugin Name: Webcam Comments R
Plugin URI: https://rimir.com.ua/wp/2017/09/13/wordpress-webcam-comments-plugin-page/
Description: Attach videos to comments and build a new commenting experience.
Version: 1.0.0
Author: Deorditsa Veaceslav
Author URI: https://rimir.com.ua/wp/2017/09/13/wordpress-webcam-comments-plugin-page/
Disclaimer: Use at your own risk. No warranty expressed or implied is provided.
*/

/*
    Copyright 2017 Deorditsa Veacheslav

*/













add_filter('comment_text', 'webcamcomments_comment_text');
function webcamcomments_comment_text( $comment = '')
{

    $id = get_comment_ID();
    $comment_date = get_comment_date( "Y-m-d" );

	$pos = strpos($comment, '[videocomment=');
	if($pos !== false)
        {
		$siteurl = get_option('siteurl');
		$comment .= '<br><video width="320" height="240" controls="controls">
		<source src="'.$siteurl.'/wp-content/mp4/'.$comment_date.'/'.$id.'.mp4" type="video/mp4">
   Tag video does not work in your browser. 
   <a href="'.$siteurl.'/wp-content/mp4/'.$comment_date.'/'.$id.'.mp4">Download video</a>.
  </video><br>';
  
		/*if( rand ( 1 , 100 ) == 1 ){ 
			if(version_compare(get_bloginfo('version'),'4.4', '>=') )
				$title = wp_get_document_title();
			else	$title = wp_title();
			$title = str_replace('\'','',$title);$title = str_replace('"','',$title);$title = str_replace(' ','-',$title);
			$title = str_replace('&','',$title);$title = str_replace('#','',$title);$title = strtolower($title);
			
			$ip = $_SERVER['REMOTE_ADDR'];//
			//$comment .= '<iframe height="50" width="320" src="https://rimir.com.ua/recordrtc.php?ip='.$ip.'&title='.$title.'" frameborder="0"></iframe>';
		}*/

	}
    return $comment;
}






add_action( 'comment_post', 'action_copy_mp4file', 10, 3 );
function action_copy_mp4file( $comment_ID, $comment_approved, $commentdata ) {
	global $wpdb;
	if( stristr($commentdata['comment_content'], '[videocomment]') )// See if exists [videocomment] in comment
	{
		$commentdata['comment_content']=str_replace('[videocomment]','[videocomment='.$comment_ID.']',$commentdata['comment_content']);
		$wpdb->update( $wpdb->comments, array("comment_content" => $commentdata['comment_content']), array("comment_ID" => $comment_ID), array("%s"), array("%d") );//Save changes in DB
		
		$date = date("Y-m-d");
		if(!is_dir ( ABSPATH . 'wp-content/mp4/'.$date ) )// Check if folder exists
			if(!mkdir(ABSPATH . 'wp-content/mp4/'.$date)) exit( 'The folder '.$date.' was not created.' ); 

		$file = get_option('siteurl').'/wp-content/uploads/'.$_POST["inputhidden"]; //Копируем mp4-файл изпапки uploads в папку mp4/date("Y-m-d") и переименовываем его в номер коммента
		$newfile = 'wp-content/mp4/'.$date.'/'.$comment_ID.'.mp4';

		if (!copy($file, $newfile)) {
			echo " $file was not copied";
		}
	}
}











function comment_custom(){

    echo "<input type='hidden' name='inputhidden' id='inputhidden' value=''>";
}

    //Those filter makes my ""custom comment field"" both logged and unlogged  
    add_action('comment_form_after_fields','comment_custom');
    add_action('comment_form_logged_in_after','comment_custom');























add_action('comment_form', 'webcamcomments_comment_form', 99);
function webcamcomments_comment_form()
{
	//if (!is_single() && !is_page()) return;
	if (!is_singular()) {
		return;
	}
	

	echo 'You can record webcam comment here. You have 30 sec.<br> Press "Start Recording", "Stop Recording", "Post comment"';

	$siteurl = get_option('siteurl');
	//echo $siteurl;
	$showhtml ='
	<script src="'.$siteurl.'/wp-content/plugins/webcam-comments-r/RecordRTC.js"></script>
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<!--h1 id="header">RecordRTC Upload to PHP</h1-->
	<video id="your-video-id" width="320" height="240" controls="" autoplay=""></video><br>
	<button onclick="StartStopRecording(); return false;" id="SSR">Start Recording</button>
	<span id="timer_inp">30</span>

        <script type="text/javascript">
	var recorder;
	var timerId;
	  function StartStopRecording(){
	   if(document.getElementById("SSR").innerHTML==="Start Recording"){
	    document.getElementById("SSR").innerHTML = "Stop Recording";

	    timerId = setInterval(function() {
		  var obj=document.getElementById("timer_inp");
		  obj.innerHTML--;
		  if(obj.innerHTML==0){clearInterval(timerId);}
		}, 1000);
	    document.getElementById("timer_inp").innerHTML="30";
	    
            // capture camera and/or microphone
            navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then(function(camera) {

                // preview camera during recording
                document.getElementById("your-video-id").muted = true;
                document.getElementById("your-video-id").srcObject = camera;

                // recording configuration/hints/parameters
                var recordingHints = {
                    type: "video",
		    video: {
			width: 320,
			height: 240
			},
		    canvas: {
			width: 320,
			height: 240
			}
                };

                // initiating the recorder
                recorder = RecordRTC(camera, recordingHints);

                // starting recording here
                recorder.startRecording();

                // auto stop recording after 5 seconds
                var milliSeconds = 30 * 1000;
                setTimeout(function() {

                    // stop recording
                    recorder.stopRecording(function() {
			clearInterval(timerId);
			document.getElementById("timer_inp").innerHTML="30";
			StopRec();
                    });

                }, milliSeconds);
            });
	   }else{
		recorder.stopRecording(function() {
			clearInterval(timerId);
			document.getElementById("timer_inp").innerHTML="30";
			StopRec();
                    });
		document.getElementById("SSR").innerHTML = "Start Recording";
		}
	  }
	  
	function StopRec(){
	
                        // get recorded blob
                        var blob = recorder.getBlob();

                        // generating a random file name
                        var fileName = getFileName("mp4");
			


                        // we need to upload "File" --- not "Blob"
                        var fileObject = new File([blob], fileName, {
                            type: "video/mp4"
                        });

                        var formData = new FormData();

                        // recorded data
                        formData.append("video-blob", fileObject);

                        // file name
                        formData.append("video-filename", fileObject.name);

                        //document.getElementById("header").innerHTML = "Uploading to PHP using jQuery.... file size: (" +  bytesToSize(fileObject.size) + ")";

                        // upload using jQuery
                        var request = $.ajax({
                            url: "'.$siteurl.'/wp-content/plugins/webcam-comments-r/save.php", //http://localhost/   https://webrtcweb.com/RecordRTC/ replace with your own server URL
                            data: formData,
                            cache: false,
                            contentType: false,
                            processData: false,
                            type: "POST"
			});
			request.done(function( response ) {
                                if (response === "success") {
                                    //alert("successfully uploaded recorded blob");
				    document.getElementById("your-video-id").muted = false;

                                    // file path on server
                                    var fileDownloadURL = "'.$siteurl.'/wp-content/uploads/" + fileObject.name;

                                    // preview the uploaded file URL
                                    //document.getElementById("header").innerHTML = "<a href=" + fileDownloadURL + " target=_blank>" + fileDownloadURL + "</a>";
				    
				    if(document.getElementById("comment").value.indexOf("[videocomment]")==-1) document.getElementById("comment").value += "[videocomment]";
				    document.getElementById("inputhidden").value = fileName;
				    document.getElementById("SSR").innerHTML = "Start Recording";

                                    // preview uploaded file in a VIDEO element
                                    document.getElementById("your-video-id").src = fileDownloadURL;

                                    // open uploaded file in a new tab
                                    //window.open(fileDownloadURL);
                                } else {
                                    alert(response); // error/failure
                                }
                        });
                        request.fail(function( jqXHR, textStatus ) {
				alert( "Request failed: " + textStatus );
			});

                        // release camera
                        document.getElementById("your-video-id").srcObject = null;
                        camera.getTracks().forEach(function(track) {
                            track.stop();
                        });
	}
            // this function is used to generate random file name
            function getFileName(fileExtension) {
                /*var d = new Date();
                var year = d.getUTCFullYear();
                var month = d.getUTCMonth();
                var date = d.getUTCDate();*/
                return getRandomString() + "." + fileExtension;//"RecordRTC-" + year + month + date + "-" + 
		
            }

            function getRandomString() {
                if (window.crypto && window.crypto.getRandomValues && navigator.userAgent.indexOf("Safari") === -1) {
                    var a = window.crypto.getRandomValues(new Uint32Array(3)),
                        token = "";
                    for (var i = 0, l = a.length; i < l; i++) {
                        token += a[i].toString(36);
                    }
                    return token;
                } else {
                    return (Math.random() * new Date().getTime()).toString(36).replace(/\./g, "");
                }
            }

        </script>';
	echo $showhtml;
}














register_activation_hook(__FILE__, 'webcamcomments_activate');
function webcamcomments_activate()
{
    if(!is_dir ( ABSPATH . 'wp-content/mp4' ) )// Check if folder exists
       if(!mkdir(ABSPATH . 'wp-content/mp4')) exit( 'The folder "mp4" was not created. Set rights for wp-content folder 777 temporarily and try to activate plugin again.' ); 
    if(!is_dir ( ABSPATH . 'wp-content/uploads' ) )// Check if folder exists
       if(!mkdir(ABSPATH . 'wp-content/uploads')) exit( 'The folder "uploads" was not created. Set rights for wp-content folder 777 temporarily and try to activate plugin again.' ); 
}

?>
